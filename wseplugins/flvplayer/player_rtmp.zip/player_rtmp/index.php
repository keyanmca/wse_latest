<?

//exemplo

//   $fmsurl="rtmp://mediacp.ciclanohost.com.br:1935/8048";
//   $stream="8048";

// agora mude abaixo para os seus dados

$fmsurl="";
$stream="";

?>

<title>WEBTV PLAYER HD</title>
       <DIV id=streaming_ciclanohost>
<P><A href="http://www.adobe.com/go/getflashplayer"><IMG 
alt="Get Adobe Flash player" 
src="get_flash_player.gif"></A></P></DIV>
<DIV id=streaming_ciclanohost></DIV>
<SCRIPT type=text/javascript src="swfobject.js"></SCRIPT>

<SCRIPT type=text/javascript>
					var flashvars = {
					menu:"true",
					 flvpVideoSource: "<? echo $fmsurl; ?>,<? echo $stream; ?>",
					 flvpWidth: "530",
					 flvpHeight: "400",
					 logo: "ciclano.swf",
					 stretching: "fill"
					};
					 var params = {

					 menu: "true",
					 allowfullscreen: "true",
					 wmode: "transparent"
					};
					swfobject.embedSWF("ciclano_player.swf", "streaming_ciclanohost", "530", "400", "9.0.0", "reload_ciclano.swf", flashvars, params);

					</SCRIPT>
                    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-30135425-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>